#include <Uefi.h>
#include <Protocol/GraphicsOutput.h>

#include <Protocol/EdidActive.h>
#include <Library/DebugLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/UefiBootServicesTableLib.h>

EFI_GRAPHICS_OUTPUT_PROTOCOL        *Gop;

EFI_STATUS GopStart(
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  ) {
   
   EFI_STATUS      status;
/*	
	    UINTN           handleCount;
    EFI_HANDLE      *handleBuffer;
	EFI_EDID_ACTIVE_PROTOCOL *Edid;
	
	  status = gBS->LocateHandleBuffer(
                    ByProtocol,
                    &gEfiEdidActiveProtocolGuid,
                    NULL,
                    &handleCount,
                    &handleBuffer);
					
					
    if (EFI_ERROR(status)) return status;
	
	   DEBUG((DEBUG_INFO,"LocateHandleBuffer Status %x %x", status,handleCount));
					   
					   
					   	    status = gBS->HandleProtocol(
                    handleBuffer[0],    // TODO
                    &gEfiEdidActiveProtocolGuid,
                    (VOID **)&(Edid));

					DEBUG((DEBUG_INFO,"Edid Status %x", status));
					   
		 DEBUG((DEBUG_INFO,"SizeofEdid %x", Edid->SizeOfEdid));
					   
			*/		   
	
    UINTN           handleCount;
    EFI_HANDLE      *handleBuffer;

	  UINT32     ModeNumber=0;
    UINT32     MaxMode;

  UINTN      SizeOfInfo;
  EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *Info;
    status = gBS->LocateHandleBuffer(
                    ByProtocol,
                    &gEfiGraphicsOutputProtocolGuid,
                    NULL,
                    &handleCount,
                    &handleBuffer);
    if (EFI_ERROR(status)) return status;
	
	
					   DEBUG((DEBUG_INFO,"LocateHandleBuffer Status %x %x", status,handleCount));
					   

    status = gBS->HandleProtocol(
                    handleBuffer[0],    // TODO
                    &gEfiGraphicsOutputProtocolGuid,
                    (VOID **)&(Gop));
								MaxMode = Gop->Mode->MaxMode;

					   DEBUG((DEBUG_INFO,"MaxMode Status %x\n", MaxMode));
	    status = gBS->HandleProtocol(
                    handleBuffer[1],    // TODO
                    &gEfiGraphicsOutputProtocolGuid,
                    (VOID **)&(Gop));
								MaxMode = Gop->Mode->MaxMode;

					 

					
					
					MaxMode = Gop->Mode->MaxMode;

					   DEBUG((DEBUG_INFO,"MaxMode Status %x\n", MaxMode));
  for (ModeNumber = 0; ModeNumber < MaxMode; ModeNumber++) {
    status = Gop->QueryMode (
                       Gop,
                       ModeNumber,
                       &SizeOfInfo,
                       &Info
                       );
					   
					   
					   
					   DEBUG((DEBUG_INFO,"QueryMode ModeNumber HR VR %x %x %x", ModeNumber,Gop->Mode->Info->HorizontalResolution,Gop->Mode->Info->VerticalResolution));
  }
  
					status= Gop->QueryMode (
                       Gop,
                       ModeNumber,
                       &SizeOfInfo,
                       &Info
                       );
					   
					   
					   DEBUG((DEBUG_INFO,"QueryMode Status %x", status));
					   
    if (EFI_ERROR(status)) return status;

    FreePool(handleBuffer);
	
    return status;
}